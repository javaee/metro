/*
 * MtomService.java
 *
 * Created on August 15, 2007, 4:02 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package mtom;

import com.sun.xml.ws.transport.http.HttpAdapter;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

/**
 *
 * @author vivekp
 */
@WebService()
@MTOM
public class MtomService {
    static{
        HttpAdapter.dump = true;
    }
    /**
     * Web service operation
     */
    @WebMethod    
    public byte[] echoBinary(@WebParam(name = "data") byte[] data) {
        return data;
    }
    
}
